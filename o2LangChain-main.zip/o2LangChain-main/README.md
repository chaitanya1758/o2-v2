[![KITT badge](https://kitt-badges.k8s.walmart.com/kittbadge?org=walmart-web&repo=o2LangChain)](https://concord.prod.walmart.com/#/org/strati/project/pipeline/process?meta.repoMetadata=walmart-web%2Fo2LangChain&limit=50)

# LangChain Python Starter Kit

This starter kit provides a preconfigured base setup for using the LangChain framework in a Python Flask application. It showcases the memory management, chaining, and analysis functionalities of LangChain and integrates with the Walmart GenAI Platform for making LLM calls.
This starter kit will generate a Python REST Microservice preconfigured with everything you need to deploy an application in WCNP.

## Features

### LangChain Capabilities
| Feature | Status | Description |
|---------|--------|-------------|
| **Memory Management** | ✅ | Conversation memory with session management |
| **Sequential Chaining** | ✅ | Multi-step story generation with outline → story → moral |
| **Analysis Chaining** | ✅ | Text analysis with summarization → sentiment → topics |
| **Custom LLM Integration** | ✅ | Walmart LLM Gateway integration with security controls |
| **Session Management** | ✅ | Create, clear, and list conversation sessions |
| **Error Handling** | ✅ | Comprehensive error handling and validation |

### Platform Integration
| Feature | Status | Description |
|---------|--------|-------------|
| **WCNP Deployment** | ✅ | Ready for Walmart Cloud Native Platform |
| **Service Registry** | ✅ | Automatic registration with Walmart's Service Registry |
| **CCM Integration** | ✅ | Cloud Configuration Management |
| **Metrics & Monitoring** | ✅ | Prometheus metrics and health checks |
| **Security Controls** | ✅ | Input validation and SSRF protection |
| **Structured Logging** | ✅ | OTEL-compliant logging |
| **API Documentation** | ✅ | OpenAPI 3.0 specification with Swagger UI |

## How to read this document?

- [Integration with Walmart GenAI Platform](#GenAIPlatform)
- [LangChain Features Overview](#LangChainFeatures)
- [Steps for Local Development](#localdevelopment)
- [API Endpoints](#apiendpoints)
- [Deployment steps](#steps)
- [How to verify onboarding is successful?](#VerifyOnboarding)
- [Common troubleshooting scenarios](https://dx.walmart.com/documents/article/jjiam6s390)
- [Canonical pipeline integration](#canonicalpipeline)
- [How to promote Starter Kit into a stage environment](#stagedeployment)

<a name=GenAIPlatform></a>

## Integration with Walmart GenAI Platform

This application uses the REST API way of accessing the LLM models hosted on GenAI Element Platform. The integration is handled through a custom `WalmartLLM` class that provides secure access to the LLM Gateway.

### API Key Configuration

The application loads the API key through Walmart's centralized secrets management:

1. **Local Development**: Place your API key in `etc/secrets/secrets.json`:
```json
{
  "llama3-2.apiKey": "your-api-key-here"
}
```

2. **WCNP Environment**: The API key is automatically loaded from `/etc/secrets/secrets.json` via Akeyless integration.

### SSL Certificate Configuration

1. **Local Development**: Create the secrets file for local development `/etc/ssl/certs/ca-bundle.crt`:

Walmart CA Bundle 
https://gecgithub01.walmart.com/MLPlatforms/elementGenAI/blob/main/examples/llm_gateway/ca-bundle.crt

2. **WCNP Environment**: The API key is automatically loaded from `/ca-bundle.crt` via Akeyless integration. Create the certifcate file for prod deployement update the path in akeyless section of `kitt.yaml`

### LLM Configuration

The default configuration uses:
- **Model**: `llama-3-2-90b-vision-instruct`
- **Gateway URL**: `https://wmtllmgateway.stage.walmart.com/wmtllmgateway/v1/generate`
- **Max Tokens**: 100 (configurable)
- **Temperature**: 0.1 (configurable)

<a name=localdevelopment></a>

## Steps for Local Development

### Prerequisites
- Python 3.10+
- pip or uv package manager

### Step-by-step Setup

1. **Clone the repository**
```bash
git clone git@gecgithub01.walmart.com:walmart-web/o2LangChain.git
cd o2LangChain
```

2. **Set up Python environment**
```bash
# Using uv (recommended)
uv venv
source .venv/bin/activate
uv pip install -r requirements.txt

# Or using pip
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

3. **Configure API Key**
Create the secrets file for local development:
```bash
mkdir -p etc/secrets
echo '{"llama3-2.apiKey": "your-walmart-genai-api-key"}' > etc/secrets/secrets.json
```

4. **Configure SSL Certificate**
Create the secrets file for local development `/etc/ssl/certs/ca-bundle.crt`:

Walmart CA Bundle 
https://gecgithub01.walmart.com/MLPlatforms/elementGenAI/blob/main/examples/llm_gateway/ca-bundle.crt

5. **Run the application**
```bash
python -m app_server
```

The application will start on `http://localhost:8080`

6. **Access API Documentation**
Visit `http://localhost:8080/ui/` for the Swagger UI interface.


<a name=LangChainFeatures></a>

## LangChain Features Overview

### 1. Memory Management (`/langchain/chat`)
Maintains conversation context across multiple interactions:
```bash
curl -X POST "http://localhost:8080/langchain/chat" \
  -H "Content-Type: application/json" \
  -d '{"session_id": "user123", "message": "Hello, my name is Alice."}'
```

### 2. Sequential Chaining (`/langchain/chain/sequential`)
Demonstrates multi-step processing (outline → story → moral):
```bash
curl -X POST "http://localhost:8080/langchain/chain/sequential" \
  -H "Content-Type: application/json" \
  -d '{"topic": "friendship and loyalty"}'
```

### 3. Analysis Chaining (`/langchain/chain/analysis`)
Performs comprehensive text analysis (summary → sentiment → topics):
```bash
curl -X POST "http://localhost:8080/langchain/chain/analysis" \
  -H "Content-Type: application/json" \
  -d '{"text": "Today was an amazing day! I got promoted at work and my team celebrated with me."}'
```

### 4. Session Management
- **Get Session Info**: `GET /langchain/session/info?session_id=<id>`
- **Clear Session**: `DELETE /langchain/session/clear`
- **List All Sessions**: `GET /langchain/sessions`

<a name=apiendpoints></a>

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Application health check |
| `/metrics` | GET | Prometheus metrics |
| `/langchain/chat` | POST | Chat with memory |
| `/langchain/chain/sequential` | POST | Sequential story generation |
| `/langchain/chain/analysis` | POST | Text analysis chain |
| `/langchain/session/info` | GET | Get session information |
| `/langchain/session/clear` | DELETE | Clear a session |
| `/langchain/sessions` | GET | List all active sessions |
| `/langchain/test` | POST | Test LLM connectivity |

<a name=steps></a>

## Deployment Steps

The Python LangChain starter kit by default uses the lab environment for deployments.

**1. To Trigger a WCNP Deployment**

To trigger a WCNP deployment, the repo needs a commit for concord to trigger the CICD. To deploy the starter kit as is, please do a dummy commit by touching any file. For example, add an empty line to "README.md"
 
**2. KITT GitOps**

In the Slack or Teams channel given during repo creation, you will get the deployment success message.

```
:kitt-icon-blue:
KITTAPP  22 hours ago
Build started on main.
:kitt-icon-blue:
KITTAPP  22 hours ago
All services built successfully, resuming any deployment steps.
:kitt-icon-blue:
KITTAPP  22 hours ago
Beginning deployment to lab
:kitt-icon-blue:
KITTAPP  22 hours ago
Deployment to lab successful.
:kitt-icon-blue:
KITTAPP  22 hours ago
Pipeline completed successfully.
```

**3. Determine our Cluster Endpoint**

After the "Pipeline completed successfully", let's find what our Cluster_Endpoint is. Run the following command in your notification channel:
```
!deployment -n cxo -a o2LangChain -c scus-lab-a1
```

Your CLUSTER_ENDPOINT will be defined similar to the reference below:
```
Endpoints:
       GSLB: o2LangChain-lab.cxo.k8s.glb.us.walmart.net
       CName:
          o2LangChain.cxo.lab.k8s.walmart.net
       Cluster: o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net
```

In this case, `<CLUSTER_ENDPOINT>` = `o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net`

**4. Test API with Swagger**

In a browser, navigate to:
```
https://o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net/ui/
```

**5. Test LangChain APIs with CURL**

Wait for a couple of minutes and then use the curl commands to test the LangChain APIs:

```bash
# Test the memory functionality
curl -v --location --request POST 'https://o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net/langchain/chat' \
  -H 'Content-Type: application/json' \
  -d '{"session_id": "test_session_1", "message": "Hello, my name is Alice. What can you help me with?"}'
```

```bash
# Test the sequential chaining functionality
curl -v --location --request POST 'https://o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net/langchain/chain/sequential' \
  -H 'Content-Type: application/json' \
  -d '{"topic": "artificial intelligence and human collaboration"}'
```

```bash
# Test the analysis chaining functionality  
curl -v --location --request POST 'https://o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net/langchain/chain/analysis' \
  -H 'Content-Type: application/json' \
  -d '{"text": "Today was an amazing day! I got promoted at work and my team celebrated with me. We went out for dinner and shared stories about our journey together."}'
```

```bash
# List all active sessions
curl -v --location --request GET 'https://o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net/langchain/sessions'
```

<a name=VerifyOnboarding></a>

## How to verify onboarding is successful?

**1. Validate Service Registry**

In a browser, paste:
```
https://reg.soa.walmart.com/appsearch/O2LANGCHAIN-O2LANGCHAIN
```
You will see that your application has automatically been registered in the Service Registry UI.

**2. Validate CCM**

In a browser, paste:
```
https://admin.tunr.non-prod.walmart.com/services/O2LANGCHAIN-O2LANGCHAIN/service-configs/NON-PROD-1.0/configs/definition/application
```
You will see that CCM2 UI has been populated with the configs defined in your ccm.yml.

**3. Health checks**

In a browser, paste:
```
https://o2LangChain.cxo.scus-lab-a1.cluster.k8s.us.walmart.net/health
```

This endpoint should show the following response if it's up and running:
```json
{
    "status": "UP"
}
```

**4. Verifying metrics and golden signals on MMS Grafana**

Follow steps on the below link to verify the golden signal:
https://dx.walmart.com/documents/article/7n0ilg88h7

Dashboard URLs (Lab cluster):

Golden signals dashboard:
```
https://grafana.mms.walmart.net/d/QH3Ldm8YZ/golden-signals-dashboard?orgId=1&var-datasource=non-production&var-wm_app=O2LANGCHAIN-O2LANGCHAIN&var-envtype=lab&var-wm_env=dev&var-namespace=All&var-cluster_id=All&var-pod=All&var-long_interval=10m&var-hosts=All
```

Istio service dashboard:
```
http://grafana.scus-lab-a1.cluster.k8s.us.walmart.net/d/LJ_uJAvmn/istio-service-dashboard-lite?orgId=1&refresh=1m&var-namespace=cxo&var-app=o2LangChain&var-destination=All
```

App pod metrics dashboard:
```
http://grafana.scus-lab-a1.cluster.k8s.us.walmart.net/d/7Wushy_mk/apps?orgId=1&var-datasource=Prometheus&var-namespace=cxo&var-app=o2LangChain&var-interval=$__auto_interval_interval&var-long_interval=$__auto_interval_long_interval
```

**5. Exposing JMX Port and Usage**

Follow steps on the below link to set up JMX Port:
https://dx.walmart.com/documents/article/5wb8pb4rkc

**6. Remote Debugging**

Follow steps on the below link to set up Remote Debugging capability:
https://dx.walmart.com/documents/article/oe4iyiuk6w

**7. Optional SR reporting**

Follow steps on the below link to set up optional Service Registry feature enhancements:
https://dx.walmart.com/documents/product/Service%20Registry/375mbfsg3o#setup

<a name=canonicalpipeline></a>

## Canonical Pipeline Integration

Canonical pipelines are off-the-shelf CI/CD pipeline templates to enable developers to build and deploy with speed and quality. As part of the first iteration, they are being made available as part of DX starter kits. They are inherently SDLC policy compliant and have built-in gates and pipeline observability.

Please check out https://dx.walmart.com/documents/article/gzq7byof3o for more information.

### Test Hub Integration

Python LangChain Starter Kit is integrated with Test Hub for reporting test results.

**What is Test Hub?**

Test Hub is a cloud-based test reporting dashboard to help teams review, analyze and assess test results and quality of their application. It will also be used for gating in the future in CI/CD pipeline, as well as "evidence" of testing for CRQs as well as Audits.

To learn more about Test Hub, please visit: https://dx.walmart.com/documents/product/Testburst/overview

**How to onboard an application to Test Hub?**

To onboard to Test Hub, there are a few simple steps to follow, which are defined in: https://testburst.walmart.com/headerIconContent?contentKey=21

Once you follow the instructions to onboard your application, please update the test configuration with your application name to start reporting.

Note: The Starter Kit uses pytest, so follow the guide for pytest in the above webpage.

## Local Development Settings

### Running Tests

```bash
# Run all tests
python -m pytest

# Run with coverage
python -m pytest --cov=app_server --cov-report=html

# Run specific test files
python -m pytest app_server/test/test_langchain_service.py
python -m pytest app_server/test/test_langchain_controller.py
```

### Build and Run with Docker

Follow the link to get started with Docker development:
https://dx.walmart.com/documents/article/xflrgzwwhq

```bash
# Build the Docker image
docker build -t langchain-starter-kit .

# Run the container
docker run -p 8080:8080 langchain-starter-kit
```

<a name=stagedeployment></a>

## How to promote Starter Kit into a stage environment

As by default Python LangChain Starter Kit uses lab environment for deployments, we are providing extensibility to promote Starter Kit into stage environment. Please follow the below link for detailed steps:

https://dx.walmart.com/documents/article/96u9o4u2xl

## Security Notes

The LangChain Python Starter Kit includes several security features:

1. **Input Validation**: All user inputs are validated to prevent injection attacks
2. **SSRF Protection**: URL validation and request filtering to prevent Server-Side Request Forgery
3. **API Key Security**: Secure API key loading through centralized secrets management
4. **Immutable Configuration**: LLM Gateway URL is hardcoded and cannot be overridden
5. **Request Timeout**: All external requests have timeout limits
6. **Content Filtering**: Input content is validated for malicious patterns

## Common Troubleshooting Scenarios

Refer to the following document for common troubleshooting scenarios:
https://dx.walmart.com/documents/article/jjiam6s390#0fpm39ljml

### Common Issues

1. **API Key Not Found**: Ensure your API key is properly set in `etc/secrets/secrets.json` for local development
2. **LLM Gateway Timeout**: Check network connectivity and API key validity
3. **Session Not Found**: Sessions are stored in memory and will be lost on application restart
4. **Import Errors**: Ensure all dependencies are installed with `pip install -r requirements.txt`

## Optional Pre-Commit

For users familiar with pre-commit and if you would like to use the feature, Starter Kit provides a set of configurations in `.pre-commit-config.yaml` file. Please review and enable the required hooks.

To set up pre-commit to run in local machine, please use the below commands. To learn more about pre-commit, please visit https://pre-commit.com/

```bash
pip install pre-commit
pre-commit install
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## Support

For issues or questions:
- Post in the Slack channel provided during repository creation
- Create an issue in the GitHub repository
- Refer to the troubleshooting documentation above

## License

This project is licensed under Walmart's internal license. See the LICENSE file for details.
