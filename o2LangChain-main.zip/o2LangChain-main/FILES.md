# File Structure

/.dockerignore -> Files and Directories to ignore from including in Dockerfile
/.dxstarter -> Tracks starter kit used with what version, and the latest migration applied
/.dxstarterpython -> Saves original key value pair initially defined by the user during creation
/.pre-commit-config.yaml -> Checks to be run on commit
/Dockerfile -> Used by Docker to configure the container for the sample application
/FILES.md -> Brief explanation of files within Python Starter Kit
/README.md -> Read this for information on how to use the Python Starter Kit
/api-spec.yaml -> OpenAPI 3.0 API Spec File
/automaton_global_config.json -> Defines performance jobs to be run in automaton
/app_server -> Sample Flask Python Application code
/ccm.yaml -> Used for Cloud Configuration Management (ccm) GitOps management
/kitt.yml -> Used for configuration of KITT, which is used for deployment on WCNP
/requirements.txt -> Used by the Python Package Manager (pip) to download python dependencies for sample application
/sonar-project.properties -> Used to configure SonarQube for testing
/sr.yaml -> Used for Service Registry (sr) GitOps management