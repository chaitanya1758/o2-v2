# Changelog

All notable changes to this project will be documented in this file.

## [v15] - 2025.04.21
Sonar coverage
stage-gates profile

## [v15] - 2024.09.05
Dummy commit


## [v14] - 2024.08.29

Changed host from 127.0.0.1 to 0.0.0.0 (the server will listen on all available network interfaces)

## [v13] - 2024.05.01

Added .cxignore file
APM ID logic 
And all enpoints for sqlerver and inmemory
db config file

## [v13] - 2024.01.15

* SQLite - In-Memory Database endpoints.

## [v13] - 2024.01.15

* Added read and delete endpoints to SQLite.

## [v13] - 2024.01.10

* Added DB choices - SQLite and Azure SQL

## [v12] - 2023.06.05

* Bug fixes for CCM, Secret files and added config for Akeyless in kitt.

## [v11] - 2023.02.27

* Updated Readme to reflect pre-commit as an optional feature for user

## [v10] - 2023.02.22

* Added steps to Enable End to End and Integration testing in Pipeline

## [v9] - 2023.02.07

* Added MLS Integration 

## [v8] - 2023.01.19

* Updated home page documentation to fix links and Akeyless Description

## [v7] - 2023.01.18

Following features and integrations were tested against Stage and Production gates. This update also gives developers the ability to deploy to a new environment with less effort, just need to follow the [Python Starter Kit Guides](https://dx.walmart.com/guides/#qfm773gwvn).

The below features and GTP product integrations are included:
* WCNP
* WCNP: Python Web Profile
* Looper
* TestBurst
* CCM V2
* Service Registry
* MMS
* Golden Signals
* Splunk
* Automaton
* Pod Profiler
* SonarQube
* API Linting
* Istio sidecar
* Stage gates configuration
* Slack, MS Teams and Email
* SRE Agent
* Akeyless
* Artifactory
