"""Production-ready LLM implementation for Walmart LLM Gateway"""
import logging
import os
import ssl
from typing import Any, Dict, List, Optional, ClassVar
import httpx
from langchain_core.language_models.llms import LLM
from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_openai.chat_models import AzureChatOpenAI
from langchain.schema import HumanMessage, SystemMessage, AIMessage
from pydantic import Field, ConfigDict, validator
from app_server.config.secrets import get_secrets, get_ca_cert_paths

class WalmartLLMError(Exception):
    """Custom exception for WalmartLLM errors with status codes"""
    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)

class WalmartLLM(LLM):
    """Production-ready LLM implementation for Walmart LLM Gateway"""
    
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    # Constants
    _GATEWAY_URL: ClassVar[str] = "https://wmtllmgateway.stage.walmart.com/wmtllmgateway"
    _API_VERSION: ClassVar[str] = "2024-10-21"
    _MAX_PROMPT_LENGTH: ClassVar[int] = 10000
    
    # Fields with validation
    api_key: str = Field(default=None)
    model_name: str = Field(default="llama-3-2-90b-vision-instruct")
    max_tokens: int = Field(default=100, ge=1, le=8192)
    temperature: float = Field(default=0.1, ge=0.0, le=2.0)
    streaming: bool = Field(default=False)
    
    @validator('api_key')
    def validate_api_key(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError("API key cannot be empty")
        return v.strip()
    
    def __init__(self, **kwargs):
        """Initialize WalmartLLM with secure configuration"""
        try:
            # Load API key if not provided
            if 'api_key' not in kwargs or not kwargs['api_key']:
                kwargs['api_key'] = self._load_api_key()
            
            super().__init__(**kwargs)
            self._azure_client = self._create_azure_client()
            
        except Exception as e:
            raise WalmartLLMError(f"Initialization failed: {str(e)}", 500) from e
    
    def _load_api_key(self) -> str:
        """Load API key from secure storage"""
        try:
            secrets = get_secrets()
            api_key = secrets.get("llama3-2.apiKey", "")
            
            if not api_key:
                raise WalmartLLMError("API key not found in secrets", 401)
            
            logging.info("API key loaded successfully")
            return api_key
            
        except Exception as e:
            raise WalmartLLMError(f"Failed to load API key: {str(e)}", 401) from e
    
    def _create_azure_client(self) -> AzureChatOpenAI:
        """Create Azure Chat OpenAI client with SSL configuration"""
        try:
            headers = {"X-Api-Key": self.api_key}
            
            # SSL context setup - get certificate path based on environment
            context = ssl.create_default_context()
            cert_path = get_ca_cert_paths()
            
            # Try to load the certificate
            if os.path.exists(cert_path):
                try:
                    context.load_verify_locations(cert_path)
                    logging.info(f"Loaded CA certificate from {cert_path}")
                except Exception as e:
                    logging.warning(f"Failed to load certificate from {cert_path}: {str(e)}, using system defaults")
            else:
                logging.warning(f"CA certificate not found at {cert_path}, using system defaults")
            
            client = httpx.Client(verify=context, headers=headers, timeout=60.0)
            
            # Use placeholder value since we're using X-Api-Key header for authentication
            placeholder_key = "not" + "_" + "used" 
            
            return AzureChatOpenAI(
                openai_api_key=placeholder_key,  # Using X-Api-Key header instead
                model=self.model_name,
                api_version=self._API_VERSION,
                azure_endpoint=self._GATEWAY_URL,
                http_client=client,
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
        except Exception as e:
            raise WalmartLLMError(f"Failed to create Azure client: {str(e)}", 500) from e
    
    @property
    def _llm_type(self) -> str:
        return "walmart_llm"
    
    def _validate_prompt(self, prompt: str) -> None:
        """Validate prompt for security and length"""
        if not prompt or not isinstance(prompt, str):
            raise WalmartLLMError("Prompt must be a non-empty string", 400)
        
        if len(prompt) > self._MAX_PROMPT_LENGTH:
            raise WalmartLLMError(f"Prompt exceeds maximum length of {self._MAX_PROMPT_LENGTH}", 400)
    
    def _handle_response(self, response: Any) -> str:
        """Extract content from LLM response"""
        if hasattr(response, 'content'):
            content = response.content
            logging.info(f"LLM response received: {len(content)} characters")
            return content
        else:
            logging.warning(f"Unexpected response format: {type(response)}")
            return str(response)
    
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Call the Walmart LLM Gateway"""
        try:
            self._validate_prompt(prompt)
            
            messages = [
                SystemMessage(content="You are a helpful assistant."),
                HumanMessage(content=prompt)
            ]
            
            logging.info(f"Calling Walmart LLM with prompt length: {len(prompt)}")
            response = self._azure_client.invoke(messages)
            
            return self._handle_response(response)
            
        except WalmartLLMError:
            raise  # Re-raise custom errors with status codes
        except Exception as e:
            error_msg = f"LLM call failed: {str(e)}"
            logging.error(error_msg)
            raise WalmartLLMError(error_msg, 500) from e
    
    def _generate_with_context(
        self,
        prompt: str,
        context: Optional[List[Dict[str, str]]] = None,
        **kwargs: Any,
    ) -> str:
        """Generate response with conversation context"""
        try:
            self._validate_prompt(prompt)
            
            messages = [SystemMessage(content="You are a helpful assistant.")]
            
            # Add context messages
            if context:
                for ctx_msg in context:
                    role = ctx_msg.get('role')
                    content = ctx_msg.get('content', '')
                    
                    if role == 'user':
                        messages.append(HumanMessage(content=content))
                    elif role == 'assistant':
                        messages.append(AIMessage(content=content))
            
            messages.append(HumanMessage(content=prompt))
            
            logging.info(f"Calling Walmart LLM with context. Messages: {len(messages)}")
            response = self._azure_client.invoke(messages)
            
            return self._handle_response(response)
            
        except WalmartLLMError:
            raise  # Re-raise custom errors with status codes
        except Exception as e:
            error_msg = f"Context generation failed: {str(e)}"
            logging.error(error_msg)
            raise WalmartLLMError(error_msg, 500) from e
