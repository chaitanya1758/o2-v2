"""LangChain service with memory and chaining capabilities"""
import logging
from typing import Dict, List, Any, Optional
from langchain.memory import ConversationBufferMemory, ConversationSummaryMemory
from langchain.chains import LLMChain, ConversationChain, SequentialChain
from langchain.prompts import PromptTemplate
from langchain_core.prompts import ChatPromptTemplate
from app_server.llm.custom_walmart_llm import WalmartLLM, WalmartLLMError

class LangChainService:
    """Service class for LangChain operations with memory and chaining"""
    
    def __init__(self):
        self.llm = WalmartLLM()
        self.sessions = {}  # Store conversation sessions
        
    def get_or_create_session(self, session_id: str) -> Dict[str, Any]:
        """Get or create a conversation session with memory"""
        if session_id not in self.sessions:
            # Create memory for this session
            memory = ConversationBufferMemory(
                memory_key="history",
                return_messages=False
            )
            
            # Create conversation chain with memory
            conversation = ConversationChain(
                llm=self.llm,
                memory=memory,
                verbose=True
            )
            
            self.sessions[session_id] = {
                "memory": memory,
                "conversation": conversation,
                "message_count": 0
            }
            
        return self.sessions[session_id]
    
    def chat_with_memory(self, session_id: str, message: str) -> Dict[str, Any]:
        """Chat with memory - demonstrates LangChain memory feature"""
        try:
            # Validate input at service level
            self.llm._validate_prompt(message)
            
            session = self.get_or_create_session(session_id)
            conversation = session["conversation"]
            memory = session["memory"]
            
            # Generate response using conversation chain with memory
            response = conversation.predict(input=message)
            
            # Update message count
            session["message_count"] += 1
            
            # Get chat history for debugging
            chat_history = memory.chat_memory.messages
            
            return {
                "response": response,
                "session_id": session_id,
                "message_count": session["message_count"],
                "chat_history_length": len(chat_history),
                "success": True
            }
            
        except WalmartLLMError as e:
            logging.error(f"WalmartLLM error in chat_with_memory: {e.message}")
            return {
                "error": e.message,
                "status_code": e.status_code,
                "session_id": session_id,
                "success": False
            }
        except Exception as e:
            logging.error(f"Error in chat_with_memory: {str(e)}")
            return {
                "error": str(e),
                "status_code": 500,
                "session_id": session_id,
                "success": False
            }
    
    def sequential_chain_example(self, topic: str) -> Dict[str, Any]:
        """Demonstrates LangChain chaining with sequential chains"""
        try:
            # Validate input at service level
            self.llm._validate_prompt(topic)
            
            # First chain: Generate a story outline
            outline_template = """
            Create a brief story outline about {topic}.
            Focus on the main plot points and characters.
            
            Story Outline:
            """
            outline_prompt = PromptTemplate(
                input_variables=["topic"],
                template=outline_template
            )
            outline_chain = LLMChain(
                llm=self.llm,
                prompt=outline_prompt,
                output_key="outline"
            )
            
            # Second chain: Expand the outline into a full story
            story_template = """
            Based on this story outline:
            {outline}
            
            Write a short story (2-3 paragraphs) that follows this outline.
            
            Short Story:
            """
            story_prompt = PromptTemplate(
                input_variables=["outline"],
                template=story_template
            )
            story_chain = LLMChain(
                llm=self.llm,
                prompt=story_prompt,
                output_key="story"
            )
            
            # Third chain: Create a moral or lesson from the story
            moral_template = """
            Based on this story:
            {story}
            
            What is the main moral or lesson that can be learned from this story?
            
            Moral/Lesson:
            """
            moral_prompt = PromptTemplate(
                input_variables=["story"],
                template=moral_template
            )
            moral_chain = LLMChain(
                llm=self.llm,
                prompt=moral_prompt,
                output_key="moral"
            )
            
            # Create sequential chain
            sequential_chain = SequentialChain(
                chains=[outline_chain, story_chain, moral_chain],
                input_variables=["topic"],
                output_variables=["outline", "story", "moral"],
                verbose=True
            )
            
            # Execute the chain
            result = sequential_chain({"topic": topic})
            
            return {
                "topic": topic,
                "outline": result["outline"],
                "story": result["story"],
                "moral": result["moral"],
                "success": True
            }
            
        except WalmartLLMError as e:
            logging.error(f"WalmartLLM error in sequential_chain_example: {e.message}")
            return {
                "error": e.message,
                "status_code": e.status_code,
                "topic": topic,
                "success": False
            }
        except Exception as e:
            logging.error(f"Error in sequential_chain_example: {str(e)}")
            return {
                "error": str(e),
                "status_code": 500,
                "topic": topic,
                "success": False
            }
    
    def analysis_chain_example(self, text: str) -> Dict[str, Any]:
        """Demonstrates chaining for text analysis"""
        try:
            # Validate input at service level
            self.llm._validate_prompt(text)
            
            # First chain: Summarize the text
            summary_template = """
            Summarize the following text in 2-3 sentences:
            
            Text: {text}
            
            Summary:
            """
            summary_prompt = PromptTemplate(
                input_variables=["text"],
                template=summary_template
            )
            summary_chain = LLMChain(
                llm=self.llm,
                prompt=summary_prompt,
                output_key="summary"
            )
            
            # Second chain: Analyze sentiment
            sentiment_template = """
            Analyze the sentiment of the following text. 
            Classify it as Positive, Negative, or Neutral and explain why.
            
            Text: {text}
            
            Sentiment Analysis:
            """
            sentiment_prompt = PromptTemplate(
                input_variables=["text"],
                template=sentiment_template
            )
            sentiment_chain = LLMChain(
                llm=self.llm,
                prompt=sentiment_prompt,
                output_key="sentiment"
            )
            
            # Third chain: Extract key topics
            topics_template = """
            Extract the main topics or themes discussed in the following text.
            List them as bullet points.
            
            Text: {text}
            
            Key Topics:
            """
            topics_prompt = PromptTemplate(
                input_variables=["text"],
                template=topics_template
            )
            topics_chain = LLMChain(
                llm=self.llm,
                prompt=topics_prompt,
                output_key="topics"
            )
            
            # Create sequential chain for analysis
            analysis_chain = SequentialChain(
                chains=[summary_chain, sentiment_chain, topics_chain],
                input_variables=["text"],
                output_variables=["summary", "sentiment", "topics"],
                verbose=True
            )
            
            # Execute the analysis chain
            result = analysis_chain({"text": text})
            
            return {
                "original_text": text[:200] + "..." if len(text) > 200 else text,
                "summary": result["summary"],
                "sentiment": result["sentiment"],
                "topics": result["topics"],
                "success": True
            }
            
        except WalmartLLMError as e:
            logging.error(f"WalmartLLM error in analysis_chain_example: {e.message}")
            return {
                "error": e.message,
                "status_code": e.status_code,
                "original_text": text[:200] + "..." if len(text) > 200 else text,
                "success": False
            }
        except Exception as e:
            logging.error(f"Error in analysis_chain_example: {str(e)}")
            return {
                "error": str(e),
                "status_code": 500,
                "original_text": text[:200] + "..." if len(text) > 200 else text,
                "success": False
            }
    
    def get_session_info(self, session_id: str) -> Dict[str, Any]:
        """Get information about a conversation session"""
        if session_id not in self.sessions:
            return {
                "session_id": session_id,
                "exists": False,
                "message": "Session not found"
            }
        
        session = self.sessions[session_id]
        memory = session["memory"]
        chat_history = memory.chat_memory.messages
        
        return {
            "session_id": session_id,
            "exists": True,
            "message_count": session["message_count"],
            "chat_history_length": len(chat_history),
            "chat_history": [
                {
                    "type": msg.type,
                    "content": msg.content[:100] + "..." if len(msg.content) > 100 else msg.content
                }
                for msg in chat_history[-5:]  # Last 5 messages
            ]
        }
    
    def clear_session(self, session_id: str) -> Dict[str, Any]:
        """Clear a conversation session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return {
                "session_id": session_id,
                "cleared": True,
                "message": "Session cleared successfully"
            }
        else:
            return {
                "session_id": session_id,
                "cleared": False,
                "message": "Session not found"
            }
    
    def list_sessions(self) -> Dict[str, Any]:
        """List all active sessions"""
        sessions_info = []
        for session_id, session in self.sessions.items():
            sessions_info.append({
                "session_id": session_id,
                "message_count": session["message_count"],
                "chat_history_length": len(session["memory"].chat_memory.messages)
            })
        
        return {
            "active_sessions": len(self.sessions),
            "sessions": sessions_info
        }
