from flask import request
from prometheus_client import Summary, Gauge
import time
import os
import threading

processTimes = {}
client_errors = {}
server_errors = {}

http_server_requests_seconds = Summary('http_server_requests_seconds', 'HTTP server request processing time in seconds',
                                       ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

processTime_seconds_count = Gauge('processTime_seconds_count:rate2m', 'Application request processing time in seconds',
                                  ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

processTime_seconds_sum = Gauge('processTime_seconds_sum:rate2m', 'Application request processing time in seconds',
                                ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

processTime_seconds_max = Gauge('processTime_seconds_max:max', 'Application request processing time in seconds',
                                ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

processTime_seconds_min = Gauge('processTime_seconds_min:min', 'Application request processing time in seconds',
                                ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

processTime_seconds_avg = Gauge('processTime_seconds:avg', 'Application request processing time in seconds',
                                ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

c4XX_total = Gauge('c4XX_total:rate2m', 'Total 4XX error returned from the application',
                   ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

c5XX_total = Gauge('c5XX_total:rate2m', 'Total 5XX error returned from the application',
                   ['wm_env', 'wm_app', 'span_kind', 'wm_peer_app'])

wm_env = os.getenv('environment', 'local')
wm_app = os.getenv('appName', 'app')


def start_timer():
    request.start_time = time.time()


def stop_timer(response):
    resp_time = time.time() - request.start_time
    http_server_requests_seconds.labels(wm_env, wm_app, 'SERVER', '_').observe(resp_time)

    processTimes[time.time_ns()] = resp_time

    threshold_ns = time.time_ns() - 120000000000
    for k in list(processTimes.keys()):
        if k < threshold_ns:
            del processTimes[k]

    processTime_seconds_count.labels(wm_env, wm_app, 'SERVER', '_').set(len(processTimes))
    processTime_seconds_sum.labels(wm_env, wm_app, 'SERVER', '_').set(sum(processTimes.values()))
    processTime_seconds_max.labels(wm_env, wm_app, 'SERVER', '_').set(max(processTimes.values(), default=0))
    processTime_seconds_min.labels(wm_env, wm_app, 'SERVER', '_').set(min(processTimes.values(), default=0))
    processTime_seconds_avg.labels(wm_env, wm_app, 'SERVER', '_').set(
        average(sum(processTimes.values()), len(processTimes)))
    return response


def average(size, length):
    return size / length if length else 0


def record_response_counter(response):
    if 400 <= response.status_code < 500:
        client_exception_handler(response)
    elif 500 <= response.status_code < 600:
        server_exception_handler(response)

    return response


def add_interceptor(app):
    app.app.before_request(start_timer)
    app.app.after_request(record_response_counter)
    app.app.after_request(stop_timer)


def client_exception_handler(response):
    client_errors[time.time_ns()] = 1

    threshold_ns = time.time_ns() - 120000000000
    for k in list(client_errors.keys()):
        if k < threshold_ns:
            del client_errors[k]

    c4XX_total.labels(wm_env, wm_app, 'SERVER', '_').set(len(client_errors))


def server_exception_handler(response):
    server_errors[time.time_ns()] = 1

    threshold_ns = time.time_ns() - 120000000000
    for k in list(server_errors.keys()):
        if k < threshold_ns:
            del server_errors[k]

    c5XX_total.labels(wm_env, wm_app, 'SERVER', '_').set(len(server_errors))


def adjust_exception_counters():
    threshold_ns = time.time_ns() - 120000000000

    for k in list(server_errors.keys()):
        if k < threshold_ns:
            del server_errors[k]

    c5XX_total.labels(wm_env, wm_app, 'SERVER', '_').set(len(server_errors))

    for k in list(client_errors.keys()):
        if k < threshold_ns:
            del client_errors[k]

    c4XX_total.labels(wm_env, wm_app, 'SERVER', '_').set(len(client_errors))

    threading.Timer(120.0, adjust_exception_counters).start()


adjust_exception_counters()
