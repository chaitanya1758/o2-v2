import tempfile
import os
from app_server.util import read_file_chunks  # Adjust import

def test_read_file_chunks():
    content = b"Python starter code coverage" * 100

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    chunks = list(read_file_chunks(tmp_path))

    # Assert that chunks recombine into original content
    assert b"".join(chunks) == content

    os.remove(tmp_path)