"""Test cases for LangChain controller endpoints"""
import pytest
import json
from unittest.mock import patch, MagicMock
from flask import Flask
from app_server.controllers import langchain_controller


@pytest.fixture
def app():
    """Create a test Flask app"""
    app = Flask(__name__)
    app.config['TESTING'] = True
    
    # Register test routes
    app.add_url_rule('/langchain/chat', 'chat_with_memory', 
                     langchain_controller.chat_with_memory, methods=['POST'])
    app.add_url_rule('/langchain/chain/sequential', 'sequential_chain', 
                     langchain_controller.sequential_chain, methods=['POST'])
    app.add_url_rule('/langchain/chain/analysis', 'analysis_chain', 
                     langchain_controller.analysis_chain, methods=['POST'])
    app.add_url_rule('/langchain/session/info', 'get_session_info', 
                     langchain_controller.get_session_info, methods=['GET'])
    app.add_url_rule('/langchain/session/clear', 'clear_session', 
                     langchain_controller.clear_session, methods=['DELETE'])
    app.add_url_rule('/langchain/sessions', 'list_sessions', 
                     langchain_controller.list_sessions, methods=['GET'])
    app.add_url_rule('/langchain/test', 'test_walmart_llm', 
                     langchain_controller.test_walmart_llm, methods=['POST'])
    
    return app


@pytest.fixture
def client(app):
    """Create a test client"""
    return app.test_client()


class TestLangChainController:
    """Test cases for LangChain controller endpoints"""
    
    @patch('app_server.controllers.langchain_controller.langchain_service')
    def test_chat_with_memory_success(self, mock_service, client):
        """Test successful chat with memory endpoint"""
        # Mock service response
        mock_service.chat_with_memory.return_value = {
            "response": "Hello! How can I help you?",
            "session_id": "test_session",
            "message_count": 1,
            "chat_history_length": 2,
            "success": True
        }
        
        response = client.post('/langchain/chat', 
                             json={
                                 "session_id": "test_session",
                                 "message": "Hello"
                             })
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["success"] is True
        assert data["session_id"] == "test_session"
        assert "response" in data
    
    def test_chat_with_memory_missing_data(self, client):
        """Test chat endpoint with missing data"""
        response = client.post('/langchain/chat')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "No JSON data provided" in data["error"]
    
    def test_chat_with_memory_missing_session_id(self, client):
        """Test chat endpoint with missing session_id"""
        response = client.post('/langchain/chat',
                             json={"message": "Hello"})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "session_id is required" in data["error"]
    
    def test_chat_with_memory_missing_message(self, client):
        """Test chat endpoint with missing message"""
        response = client.post('/langchain/chat',
                             json={"session_id": "test_session"})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "message is required" in data["error"]
    
    @patch('app_server.controllers.langchain_controller.langchain_service')
    def test_sequential_chain_success(self, mock_service, client):
        """Test successful sequential chain endpoint"""
        mock_service.sequential_chain_example.return_value = {
            "topic": "friendship",
            "outline": "Story about two friends",
            "story": "Once upon a time...",
            "moral": "Friendship is important",
            "success": True
        }
        
        response = client.post('/langchain/chain/sequential',
                             json={"topic": "friendship"})
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["success"] is True
        assert data["topic"] == "friendship"
        assert "outline" in data
        assert "story" in data
        assert "moral" in data
    
    def test_sequential_chain_missing_topic(self, client):
        """Test sequential chain endpoint with missing topic"""
        response = client.post('/langchain/chain/sequential',
                             json={})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "topic is required" in data["error"]
    
    @patch('app_server.controllers.langchain_controller.langchain_service')
    def test_analysis_chain_success(self, mock_service, client):
        """Test successful analysis chain endpoint"""
        mock_service.analysis_chain_example.return_value = {
            "original_text": "This is a test text...",
            "summary": "Test summary",
            "sentiment": "Positive",
            "topics": "Testing, Analysis",
            "success": True
        }
        
        response = client.post('/langchain/chain/analysis',
                             json={"text": "This is a test text for analysis"})
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["success"] is True
        assert "summary" in data
        assert "sentiment" in data
        assert "topics" in data
    
    def test_analysis_chain_missing_text(self, client):
        """Test analysis chain endpoint with missing text"""
        response = client.post('/langchain/chain/analysis',
                             json={})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "text is required" in data["error"]
    
    @patch('app_server.controllers.langchain_controller.langchain_service')
    def test_get_session_info_success(self, mock_service, client):
        """Test successful get session info endpoint"""
        mock_service.get_session_info.return_value = {
            "session_id": "test_session",
            "exists": True,
            "message_count": 5,
            "chat_history_length": 10
        }
        
        response = client.get('/langchain/session/info?session_id=test_session')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["session_id"] == "test_session"
        assert data["exists"] is True
    
    def test_get_session_info_missing_session_id(self, client):
        """Test get session info endpoint with missing session_id"""
        response = client.get('/langchain/session/info')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "session_id query parameter is required" in data["error"]
    
    @patch('app_server.controllers.langchain_controller.langchain_service')
    def test_clear_session_success(self, mock_service, client):
        """Test successful clear session endpoint"""
        mock_service.clear_session.return_value = {
            "session_id": "test_session",
            "cleared": True,
            "message": "Session cleared successfully"
        }
        
        response = client.delete('/langchain/session/clear',
                               json={"session_id": "test_session"})
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["cleared"] is True
        assert data["session_id"] == "test_session"
    
    def test_clear_session_missing_session_id(self, client):
        """Test clear session endpoint with missing session_id"""
        response = client.delete('/langchain/session/clear',
                                json={})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "session_id is required" in data["error"]
    
    @patch('app_server.controllers.langchain_controller.langchain_service')
    def test_list_sessions_success(self, mock_service, client):
        """Test successful list sessions endpoint"""
        mock_service.list_sessions.return_value = {
            "active_sessions": 2,
            "sessions": [
                {"session_id": "session1", "message_count": 3, "chat_history_length": 6},
                {"session_id": "session2", "message_count": 1, "chat_history_length": 2}
            ]
        }
        
        response = client.get('/langchain/sessions')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["active_sessions"] == 2
        assert len(data["sessions"]) == 2
    
    @patch('app_server.llm.custom_walmart_llm.requests.post')
    def test_test_walmart_llm_success(self, mock_post, client):
        """Test successful Walmart LLM test endpoint"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": "The capital of France is Paris."
                    }
                }
            ]
        }
        mock_post.return_value = mock_response
        
        response = client.post('/langchain/test',
                             json={"prompt": "What is the capital of France?"})
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["success"] is True
        assert "response" in data
        assert "llm_type" in data
    
    def test_test_walmart_llm_no_json(self, client):
        """Test Walmart LLM test endpoint with no JSON data"""
        response = client.post('/langchain/test')
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data
        assert "No JSON data provided" in data["error"]
