"""Test cases for LangChain service functionality"""
import pytest
import json
from unittest.mock import patch, MagicMock
from app_server.services.langchain_service import LangChainService


class TestLangChainService:
    """Test cases for LangChain service"""
    
    def setUp(self):
        self.service = LangChainService()
    
    def test_get_or_create_session(self):
        """Test session creation and retrieval"""
        service = LangChainService()
        session_id = "test_session_1"
        
        # Test session creation
        session = service.get_or_create_session(session_id)
        assert session_id in service.sessions
        assert "memory" in session
        assert "conversation" in session
        assert "message_count" in session
        assert session["message_count"] == 0
        
        # Test session retrieval
        same_session = service.get_or_create_session(session_id)
        assert same_session is session
    
    @patch('app_server.llm.custom_walmart_llm.requests.post')
    def test_chat_with_memory_success(self, mock_post):
        """Test successful chat with memory"""
        service = LangChainService()
        
        # Mock successful API response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": "Hello! How can I help you today?"
                    }
                }
            ]
        }
        mock_post.return_value = mock_response
        
        session_id = "test_session"
        message = "Hello, how are you?"
        
        result = service.chat_with_memory(session_id, message)
        
        assert result["success"] is True
        assert result["session_id"] == session_id
        assert result["message_count"] == 1
        assert "response" in result
        assert "chat_history_length" in result
    
    def test_chat_with_memory_error_handling(self):
        """Test error handling in chat with memory"""
        service = LangChainService()
        
        with patch.object(service.llm, '_call', side_effect=Exception("API Error")):
            result = service.chat_with_memory("test_session", "Hello")
            
            assert result["success"] is False
            assert "error" in result
            assert "API Error" in str(result["error"])
    
    @patch('app_server.llm.custom_walmart_llm.requests.post')
    def test_sequential_chain_example(self, mock_post):
        """Test sequential chain functionality"""
        service = LangChainService()
        
        # Mock API responses for the chain
        mock_responses = [
            "Story Outline: A tale of friendship between two unlikely companions.",
            "Full Story: Once upon a time, two friends embarked on an adventure...",
            "Moral: True friendship knows no boundaries."
        ]
        
        def side_effect(*args, **kwargs):
            response = MagicMock()
            response.status_code = 200
            response.json.return_value = {
                "choices": [
                    {
                        "message": {
                            "content": mock_responses.pop(0) if mock_responses else "Default response"
                        }
                    }
                ]
            }
            return response
        
        mock_post.side_effect = side_effect
        
        result = service.sequential_chain_example("friendship")
        
        assert result["success"] is True
        assert result["topic"] == "friendship"
        assert "outline" in result
        assert "story" in result
        assert "moral" in result
    
    def test_get_session_info_existing(self):
        """Test getting info for existing session"""
        service = LangChainService()
        session_id = "test_session"
        
        # Create a session
        service.get_or_create_session(session_id)
        
        info = service.get_session_info(session_id)
        
        assert info["session_id"] == session_id
        assert info["exists"] is True
        assert info["message_count"] == 0
        assert info["chat_history_length"] == 0
    
    def test_get_session_info_nonexistent(self):
        """Test getting info for non-existent session"""
        service = LangChainService()
        
        info = service.get_session_info("nonexistent_session")
        
        assert info["exists"] is False
        assert "Session not found" in info["message"]
    
    def test_clear_session_existing(self):
        """Test clearing existing session"""
        service = LangChainService()
        session_id = "test_session"
        
        # Create a session
        service.get_or_create_session(session_id)
        assert session_id in service.sessions
        
        # Clear the session
        result = service.clear_session(session_id)
        
        assert result["cleared"] is True
        assert session_id not in service.sessions
    
    def test_clear_session_nonexistent(self):
        """Test clearing non-existent session"""
        service = LangChainService()
        
        result = service.clear_session("nonexistent_session")
        
        assert result["cleared"] is False
        assert "Session not found" in result["message"]
    
    def test_list_sessions(self):
        """Test listing all sessions"""
        service = LangChainService()
        
        # Initially no sessions
        result = service.list_sessions()
        assert result["active_sessions"] == 0
        assert len(result["sessions"]) == 0
        
        # Create some sessions
        service.get_or_create_session("session1")
        service.get_or_create_session("session2")
        
        result = service.list_sessions()
        assert result["active_sessions"] == 2
        assert len(result["sessions"]) == 2
