# app_server/__init__.py
from flask import Flask


def create_app():
    app = Flask(__name__)
    # LangChain controller is registered via connexion in the main app
    # additional configuration and routes setup
    return app