#!/usr/bin/env python3.9

import connexion
import os
import logging
from app_server.telemetry import instrument_requests
from app_server.config import app_config
from app_server.logger import logger_config
from flask_cors import CORS
from uvicorn import Config, Server

def main():
    app = connexion.App(__name__, specification_dir='../')
    CORS(app.app)  # Enable CORS for all routes
    app.add_api('api-spec.yaml', arguments={'title': 'Python File Transfer - OpenAPI 3.0'}, pythonic_params=True)
    #TO Do change title
    app_config.start_watcher()
    instrument_requests.add_interceptor(app)
    logger_config.add_formatter()

    if 'ENV' in os.environ:
        logging.info(" * Environment: %s", os.environ['ENV'])
        #host = '127.0.0.1'
        #port = 8080
    else:
        logging.info(" * Environment: local")
        #host = 'localhost'
        #port = 9001

    # Use uvicorn to run the app
    config = Config(app, host='0.0.0.0', port=8080)
    server = Server(config)
    server.run()

if __name__ == '__main__':
    main()
