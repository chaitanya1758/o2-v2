def read_file_chunks(path):
    """ Read File

    Read file in chunks # noqa: E501

    :param path: Path to file to be read
    :type path: str

    :rtype: binary
    """

    CHUNK_SIZE = 8192
    with open(path, 'rb') as fd:
        while 1:
            buf = fd.read(CHUNK_SIZE)
            if buf:
                yield buf
            else:
                break