import os
from app_server.config import app_config


def get_file_storage():
    FILES_PATH = app_config.get_property('defaultFileStorage')

    if not FILES_PATH:
        FILES_PATH = "./files"
        if not os.path.exists(FILES_PATH):
            os.makedirs(FILES_PATH)
    return FILES_PATH
