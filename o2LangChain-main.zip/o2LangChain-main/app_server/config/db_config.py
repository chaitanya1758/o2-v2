import os


def get_db_config():
    server = "<<your server name>>"
    database = "<<your database name>>"
    return server, database



