import os
import json
import logging

# Get the environment, defaulting to "local"
environment = os.getenv('ENVIRONMENT', os.getenv('ENV', os.getenv('NODE_ENV', 'local')))

# Use the existing logger from the logger_config module
logger = logging.getLogger(__name__)


def get_secrets():
    """Get Secrets
    
    Get secrets from Akeyless based on environment.
    In local environment, reads from etc/secrets/secrets.json
    In other environments, reads from /etc/secrets/secrets.json
    
    :rtype: dict
    """
    
    logger.info(f"Environment detected: {environment}")
    if environment == "local":
        path = "etc/secrets/secrets.json"
    else:
        path = "/etc/secrets/secrets.json"
    
    try:
        with open(path, 'r', encoding='utf-8') as file:
            genai_app_secrets = json.load(file)
        
        logger.info(f"Successfully fetched secrets from {path}")
        # Log available secret keys (but not values for security)
        if genai_app_secrets:
            logger.info(f"Available secret keys: {list(genai_app_secrets.keys())}")
            # Check if the specific LLM API key exists
            llm_key = genai_app_secrets.get("llama3-2.apiKey", "")
            if llm_key:
                logger.info(f"LLM API key found: {llm_key[:10]}{'*' * (len(llm_key) - 10) if len(llm_key) > 10 else '***'}")
            else:
                logger.warning("LLM API key (llama3-2.apiKey) not found in secrets")
        else:
            logger.warning("Secrets file is empty")
        
        return genai_app_secrets
    
    except (FileNotFoundError, json.JSONDecodeError, Exception) as e:
        logger.error(f"Failed to fetch secrets from {path}: {str(e)}")
        return {}


def get_ca_cert_paths():
    """Get CA Certificate Paths
    
    Get CA certificate paths based on environment.
    In local environment, uses system CA bundle
    In other environments, uses deployed CA bundle from Akeyless
    
    :rtype: list
    """
    
    logger.info(f"Getting CA certificate paths for environment: {environment}")
    
    if environment == "local":
        # Local development - use system CA bundle
        cert_paths = "/etc/ssl/certs/ca-bundle.crt"
        logger.info("Using system CA certificate paths for local environment")
    else:
        # Production/deployed environment - use Akeyless-deployed certificate first, then fallback to system
        cert_paths = "/ca-bundle.crt"
        logger.info("Using deployed CA certificate paths for production environment")
    
    # Log which certificates actually exist
    existing_certs = []
    for cert_path in cert_paths:
        if os.path.exists(cert_path):
            existing_certs.append(cert_path)
            logger.info(f"CA certificate found at: {cert_path}")
        else:
            logger.debug(f"CA certificate not found at: {cert_path}")
    
    if existing_certs:
        logger.info(f"Available CA certificates: {existing_certs}")
    else:
        logger.warning("No CA certificates found at any of the expected paths")
    
    return cert_paths
