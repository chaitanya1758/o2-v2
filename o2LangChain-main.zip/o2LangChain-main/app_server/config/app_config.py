import os
import glob
from cachetools import TTLCache
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

cache = TTLCache(maxsize=100, ttl=86400)

path = '/etc/config'


def get_property(key):  # noqa: E501
    """Get Property

    Get specific property value from CCM configuration # noqa: E501

    :param key: Property key to be retrieved
    :type propertyKey: str

    :rtype: value: str
    """

    if cache.get("ccm", None) is None:

        properties = {}

        for filename in glob.glob(os.path.join(path, '*.properties')):
            with open(os.path.join(os.getcwd(), filename), 'r') as file:  # open in readonly mode
                for line in file:
                    if "=" in line:
                        found_key, value = line.strip().split('=', 1)
                        properties[found_key] = value.strip()
                file.close()

        cache["ccm"] = properties

        return properties.get(key, None)

    else:
        return cache["ccm"].get(key, None)


def get_properties():  # noqa: E501
    """Get Properties

    Get all property key and value from CCM configuration # noqa: E501

    :param:  None

    :rtype: value: dictionary
    """

    properties = {}

    for filename in glob.glob(os.path.join(path, '*.properties')):
        with open(os.path.join(os.getcwd(), filename), 'r') as file:  # open in readonly mode
            for line in file:
                if "=" in line:
                    key, value = line.strip().split('=', 1)
                    properties[key] = value.strip()
            file.close()

    return properties


class FileModifiedHandler(FileSystemEventHandler):
    def on_modified(self, event):
        cache.clear()
        get_property('')


def start_watcher():
    if os.path.isdir(path):
        event_handler = FileModifiedHandler()
        observer = Observer()
        observer.schedule(event_handler, path=path, recursive=False)
        observer.start()
