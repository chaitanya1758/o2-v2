import os
import glob

path = '/etc/secrets'


def get_secret(filename):  # noqa: E501
    """Get Secret

    Get specific secret value from Akeyless # noqa: E501

    :param filename: Value of secret to be retrieved
    :type secretFilename: str

    :rtype: value: str
    """

    secrets = {}

    for secret_file in glob.glob(os.path.join(path, "*.txt")):
        with open(os.path.join(os.getcwd(), secret_file), "r") as file:  # open in readonly mode
            file_name_only = str(path_leaf(file.name))
            file_contents = file.read().replace("\n", "")
            secrets[file_name_only] = file_contents
    return secrets.get(filename, None)


def path_leaf(path):
    """parse the file name only from the file path"""
    head, tail = ntpath.split(path)
    return tail or ntpath.basename(head)