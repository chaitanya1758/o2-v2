"""LangChain controller for demonstrating memory and chaining features"""
import logging
from flask import request, jsonify
from app_server.services.langchain_service import LangChainService
from app_server.llm.custom_walmart_llm import WalmartLLMError

# Initialize the LangChain service
langchain_service = LangChainService()

def _validate_input(data: dict, required_fields: list) -> tuple[bool, str]:
    """Minimal validation for required fields and basic security"""
    if not data:
        return False, "No JSON data provided"
    
    # Check required fields
    for field in required_fields:
        if field not in data or not data[field]:
            return False, f"{field} is required"
    
    return True, ""

def chat_with_memory():
    """
    Chat with memory feature - maintains conversation history
    
    Expected request body:
    {
        "session_id": "unique_session_identifier",
        "message": "Your message here"
    }
    """
    try:
        data = request.get_json()
        
        # Validate input
        is_valid, error_msg = _validate_input(data, ['session_id', 'message'])
        if not is_valid:
            return jsonify({"error": error_msg, "success": False}), 400
        
        session_id = data.get('session_id')
        message = data.get('message')
        
        logging.info(f"Processing chat with memory for session: {session_id}")
        
        # Process the chat with memory
        result = langchain_service.chat_with_memory(session_id, message)
        
        if result.get('success'):
            return jsonify(result), 200
        else:
            status_code = result.get('status_code', 500)
            return jsonify(result), status_code
            
    except WalmartLLMError as e:
        return jsonify({"error": e.message, "success": False}), e.status_code
    except Exception as e:
        logging.error(f"Error in chat_with_memory endpoint: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

def sequential_chain():
    """
    Demonstrate sequential chaining - creates story outline -> full story -> moral
    
    Expected request body:
    {
        "topic": "Topic for story generation"
    }
    """
    try:
        data = request.get_json()
        
        # Validate input
        is_valid, error_msg = _validate_input(data, ['topic'])
        if not is_valid:
            return jsonify({"error": error_msg, "success": False}), 400
        
        topic = data.get('topic')
        
        logging.info(f"Processing sequential chain for topic: {topic}")
        
        # Process the sequential chain
        result = langchain_service.sequential_chain_example(topic)
        
        if result.get('success'):
            return jsonify(result), 200
        else:
            status_code = result.get('status_code', 500)
            return jsonify(result), status_code
            
    except WalmartLLMError as e:
        return jsonify({"error": e.message, "success": False}), e.status_code
    except Exception as e:
        logging.error(f"Error in sequential_chain endpoint: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

def analysis_chain():
    """
    Demonstrate analysis chaining - summarize -> sentiment analysis -> topic extraction
    
    Expected request body:
    {
        "text": "Text to analyze"
    }
    """
    try:
        data = request.get_json()
        
        # Validate input
        is_valid, error_msg = _validate_input(data, ['text'])
        if not is_valid:
            return jsonify({"error": error_msg, "success": False}), 400
        
        text = data.get('text')
        
        logging.info(f"Processing analysis chain for text length: {len(text)}")
        
        # Process the analysis chain
        result = langchain_service.analysis_chain_example(text)
        
        if result.get('success'):
            return jsonify(result), 200
        else:
            status_code = result.get('status_code', 500)
            return jsonify(result), status_code
            
    except WalmartLLMError as e:
        return jsonify({"error": e.message, "success": False}), e.status_code
    except Exception as e:
        logging.error(f"Error in analysis_chain endpoint: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

def get_session_info():
    """
    Get information about a conversation session
    
    Expected query parameter: session_id
    """
    try:
        session_id = request.args.get('session_id')
        
        if not session_id:
            return jsonify({"error": "session_id query parameter is required"}), 400
        
        logging.info(f"Getting session info for: {session_id}")
        
        result = langchain_service.get_session_info(session_id)
        return jsonify(result), 200
        
    except Exception as e:
        logging.error(f"Error in get_session_info endpoint: {str(e)}")
        return jsonify({"error": str(e)}), 500

def clear_session():
    """
    Clear a conversation session
    
    Expected request body:
    {
        "session_id": "session_to_clear"
    }
    """
    try:
        data = request.get_json()
        
        # Validate input
        is_valid, error_msg = _validate_input(data, ['session_id'])
        if not is_valid:
            return jsonify({"error": error_msg, "success": False}), 400
        
        session_id = data.get('session_id')
        
        logging.info(f"Clearing session: {session_id}")
        
        result = langchain_service.clear_session(session_id)
        return jsonify(result), 200
        
    except Exception as e:
        logging.error(f"Error in clear_session endpoint: {str(e)}")
        return jsonify({"error": str(e)}), 500

def list_sessions():
    """
    List all active conversation sessions
    """
    try:
        logging.info("Listing all active sessions")
        
        result = langchain_service.list_sessions()
        return jsonify(result), 200
        
    except Exception as e:
        logging.error(f"Error in list_sessions endpoint: {str(e)}")
        return jsonify({"error": str(e)}), 500

def test_walmart_llm():
    """
    Test the Walmart LLM connection directly
    
    Expected request body:
    {
        "prompt": "Test prompt for the LLM"
    }
    """
    try:
        data = request.get_json()
        
        # Validate input (prompt is optional, defaults to test message)
        if data:
            is_valid, error_msg = _validate_input(data, [])
            if not is_valid:
                return jsonify({"error": error_msg, "success": False}), 400
        
        prompt = data.get('prompt', "Hello, this is a test message.") if data else "Hello, this is a test message."
        
        logging.info(f"Testing Walmart LLM with prompt: {prompt[:50]}...")
        
        # Create a temporary LLM instance and test it
        from app_server.llm.custom_walmart_llm import WalmartLLM
        llm = WalmartLLM()
        
        response = llm._call(prompt)
        
        return jsonify({
            "prompt": prompt,
            "response": response,
            "success": True,
            "llm_type": llm._llm_type
        }), 200
        
    except WalmartLLMError as e:
        return jsonify({"error": e.message, "success": False}), e.status_code
    except Exception as e:
        logging.error(f"Error in test_walmart_llm endpoint: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500
