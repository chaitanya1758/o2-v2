from flask import Response
import prometheus_client

def app_health():  # noqa: E501
    """Health indicator for the application

    Returns application health # noqa: E501

    :rtype: string
    """

    return {"message": "service up and running"}


def app_metrics():  # noqa: E501
    """Application metrics for observability

    Returns various application metrics related to Traffic, Latency, Errors # noqa: E501

    :rtype: string
    """

    CONTENT_TYPE_LATEST = str('text/plain; version=0.0.4; charset=utf-8')

    return Response(prometheus_client.generate_latest(), mimetype=CONTENT_TYPE_LATEST)
