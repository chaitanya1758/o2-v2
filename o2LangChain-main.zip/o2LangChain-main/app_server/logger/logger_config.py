import logging
import os
import sys
import json
import time
import uuid
import base64
import socket
from app_server.config import app_config

wm_env = os.getenv('environment', 'local')
wm_app = os.getenv('appName', 'app')
app_version = os.getenv('appVersion', '0.0.1')
wm_profile = os.getenv('profile', 'local')
wm_cluster = os.getenv('clusterId', 'local')
wm_site = os.getenv('site', 'local')

logging_record_factory = logging.getLogRecordFactory()

def record_factory(*args, **kwargs):
    record = logging_record_factory(*args, **kwargs)
    record.msgId = str(uuid.uuid4())
    record.txnId = str(uuid.uuid4())
    record.timeStamp = time.time_ns()
    record.traceId = str(base64.b64encode(str(uuid.uuid4()).encode('utf-8')), 'utf-8')
    record.spanId = str(base64.b64encode(str(uuid.uuid4().int>>64).encode('utf-8')), 'utf-8').strip("=")
    return record

logging.setLogRecordFactory(record_factory)

def add_formatter():
    stream_handler = logging.StreamHandler(sys.stdout)
    log_format = logging.Formatter(fmt=get_log_format(),
                                     datefmt=get_date_format())
    stream_handler.setFormatter(log_format)
    logging.getLogger().addHandler(stream_handler)

    if get_log_level() == "DEBUG":
        logging.getLogger().setLevel(logging.DEBUG)
    elif get_log_level() == "WARN":
        logging.getLogger().setLevel(logging.WARNING)
    elif get_log_level() == "ERROR":
        logging.getLogger().setLevel(logging.ERROR)
    elif get_log_level() == "TRACE":
        logging.getLogger().setLevel(logging.CRITICAL)
    else:
        logging.getLogger().setLevel(logging.INFO)

    logging.debug("logging library configured with strati platform logging configuration")


def get_log_level():
    log_level = app_config.get_property('com.walmart.platform.logging.console.level')
    if not log_level:
        log_level = "INFO"
    return log_level


def get_log_platform():
    log_format = app_config.get_property('com.walmart.platform.logging.file.format')
    if not log_format:
        log_format = "OTelJson"
    return log_format


def get_log_format():
    log_platform = get_log_platform()
    if log_platform == "V4Log" or log_platform == "V4LogSimple":
        return "WMPLTFMLOG" + str(uuid.uuid4().int)[:6] + "    %(timeStamp)s   %(asctime)s.%(msecs)03d " + socket.getfqdn() + "   %(txnId)s 0.0 %(txnId)s -   " + wm_env + " " + wm_app+ "    " + wm_site + " " + wm_profile + "   " + app_version + "   %(msgId)s %(levelname)s  %(levelname)s   -      -      -      -   %(message)s  %(spanId)s    %(txnId)s -"
    elif log_platform == "V4Json":
        data = {}

        data["signature"] = "WMPLTFMLOG" + str(uuid.uuid4().int)[:6]
        data["spanId"] = "%(spanId)s"
        data["msgId"] = "%(msgId)s"
        data["traceparent"] = "%(txnId)s"
        data["txnId"] = "%(txnId)s"
        data["topTxnId"] = "%(txnId)s"
        data["txnLevel"] = "0.0"
        data["serverName"] = socket.getfqdn()
        data["envType"] = wm_profile
        data["appId"] = wm_app
        data["time"] = "%(asctime)s.%(msecs)03d"
        data["log"] = "%(message)s"
        data["dc"] = wm_site
        data["environment"] = wm_env
        data["appVersion"] = app_version
        data["timeStamp"] = "%(timeStamp)s"
        data["type"] = "%(levelname)s"

        return json.dumps(data)
    elif log_platform == "OTelLog":
        return "%(timeStamp)s   %(traceId)s    %(spanId)s    %(levelname)s    %(levelno)s    %(message)s    " + socket.getfqdn() + "    " + wm_app + "    " + wm_env + "    " + app_version + "    " + wm_profile + "    " + wm_cluster + "    %(funcName)s    %(lineno)d    %(module)s    %(threadName)s"
    else:  # OTelJson
        data = {}
        resource = {}
        resource_attributes = {}
        attributes = {}

        data["Timestamp"] = "%(timeStamp)s"
        data["Resource"] = resource
        data["Attributes"] = attributes
        data["TraceId"] = "%(traceId)s"
        data["SpanId"] = "%(spanId)s"
        data["SeverityText"] = "%(levelname)s"
        data["SeverityNumber"] = "%(levelno)s"
        data["Body"] = "%(message)s"

        resource["Attributes"] = resource_attributes

        resource_attributes["wm.host.id"] = socket.getfqdn()
        resource_attributes["wm.app"] = wm_app
        resource_attributes["wm.env"] = wm_env
        resource_attributes["wm.app.version"] = app_version
        resource_attributes["deployment.environment"] = wm_profile
        resource_attributes["cloud.availability_zone"] = wm_cluster

        attributes["code.function"] = "%(funcName)s"
        attributes["code.lineno"] = "%(lineno)d"
        attributes["code.namespace"] = "%(module)s"
        attributes["thread.id"] = "%(threadName)s"

        return json.dumps(data)


def get_date_format():
    return "%Y-%m-%d %H:%M:%S"
