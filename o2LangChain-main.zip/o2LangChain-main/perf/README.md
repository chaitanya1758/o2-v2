This folder contains files that are related to performance testing with Automaton - JMeter.

More information about performance/load testing, Automaton, and JMeter usage can be found here: https://dx.walmart.com/documents/product/Automaton/7z41uzdj7l

perf.jmx - Configuration file for performance testing with JMeter
