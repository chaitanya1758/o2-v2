# Docker entrypoint
export $(cat /etc/secrets | grep -v "^#" | xargs)
export $(cat /etc/config | grep -v "^#" | xargs)

echo ""
echo "Starting backend"
echo ""
cd /opt
python3 ./app/backend/app.py
if [ $? -ne 0 ]; then
    echo "Failed to start backend"
    exit $?
fi