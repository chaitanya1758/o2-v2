import time

import streamlit as st
from response_generator import generate_response


def clear_prompt():
    st.session_state.query = ""


st.set_page_config(layout="wide")

# Get the toggle state from session_state
wmt_data: bool = st.session_state.get("wmt_data_toggle", True)

with st.container(height=500):
    # Set the WalmartData/Internet Toggle
    toggle_label = "Use Walmart Benefits Data" if wmt_data else "Use Internet"
    st.toggle(label=toggle_label, value=wmt_data, key="wmt_data_toggle", on_change=clear_prompt)

    if prompt := st.text_input(label="Enter your query",
                               max_chars=1024,
                               type="default",
                               key="query"):
        response = generate_response(prompt)
        st.markdown(response)


if wmt_data:
    queries = [
        "What are my 401k benefits?",
        "How many days of annual leaves am I eligible for?",
        "Does my insurance cover dental health?"
    ]
else:
    queries = [
        "What is e = mc^2?",
        "Why is water called the universal solvent?",
        "Who was the first man on the Moon?"
    ]
st.divider()
st.markdown("**Sample Queries You Can Ask**")
left, center, right = st.columns(3, gap="medium", vertical_alignment="center")
left.text_area(label="SampleQuery1", value=queries[0], disabled=True, label_visibility="hidden")
center.text_area(label="SampleQuery1", value=queries[1], disabled=True, label_visibility="hidden")
right.text_area(label="SampleQuery1", value=queries[2], disabled=True, label_visibility="hidden")
