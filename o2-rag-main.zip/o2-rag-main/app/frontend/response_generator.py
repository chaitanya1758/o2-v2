import os.path
from typing import Dict

import streamlit as st
import requests


def generate_response(prompt: str) -> str:
    with st.spinner("Generating Response..."):
        wmt_data = st.session_state.get("wmt_data_toggle", True)
        url = "http://localhost:8080/rag_ask" if wmt_data else "http://localhost:8080/ask"
        response = requests.post(url,
                                 json={'prompt': prompt},
                                 headers={'Content-Type': 'application/json', 'Accept': '*/*'})
        if not response.ok:
            return "Error in Generating Response: " + response.text

        resp_json = response.json()
        answer: str = resp_json.get("answer", "")
        sources: Dict[str, str] = resp_json.get("sources", {})

        sources_md = ""
        if "I don't know" not in answer and len(sources) > 0:
            sources_md = "SOURCES\n\n"
            for file, content in sources.items():
                sources_md += f"[{file}](http://localhost:8080/content/{os.path.basename(file)})\n\n"

        return answer + "\n\n" + sources_md


