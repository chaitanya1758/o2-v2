import json
import logging
import sys

import structlog
from flask import Flask, request, send_file
from flask_cors import CORS

from rag import RAG

# Simple retrieve-then-read implementation, using Vector Search and Converse through langchain. It first retrieves
# top documents from search, then constructs a prompt with them, and then uses Converse to generate an completion 
# (answer) with that prompt.

logger = logging.getLogger("uvicorn.error")
logging.getLogger().addHandler(logging.StreamHandler(sys.stderr))

app = Flask(__name__)
app.logger.setLevel(logging.DEBUG)
CORS(app)

# Initialize the in-memory vector db.
rag = RAG()


# @app.route("/", defaults={"path": "index.html"})
# @app.route("/<path:path>")
# def static_file(path):
#     return app.send_static_file(path)


@app.route("/content/<file>")
def content_file(file):
    return send_file('data/' + file)


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()

    logger.info(
        {
            **data
        }
    )
    response_headers = {
        'Content-Type': 'application/json'
    }
    try:
        resp = rag.llm.invoke(data['prompt'])
        resp_json = {
            "query": data['prompt'],
            "answer": resp,
            "sources": []
        }
        return json.dumps(resp_json), 200, response_headers
    except Exception as e:
        return json.dumps({"error": e}), 400, response_headers


@app.route("/rag_ask", methods=["POST"])
def rag_ask():
    data = request.get_json()

    logger.info(
        {
            **data
        }
    )
    response_headers = {
        'Content-Type': 'application/json'
    }
    try:
        rag_resp = rag.retrieve_and_generate(data['prompt'])
        return json.dumps(rag_resp.as_dict()), 200, response_headers
    except Exception as e:
        return json.dumps({"error": e}), 400, response_headers


if __name__ == '__main__':
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.dev.set_exc_info,
            structlog.processors.TimeStamper(fmt='iso'),
            structlog.processors.JSONRenderer()
        ]
    )
    logger = structlog.get_logger()
    app.run(host='0.0.0.0', port=8080)
