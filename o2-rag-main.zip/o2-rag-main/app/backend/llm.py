import logging
from typing import List, Any, Optional

import requests
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models import LLM

from models.document import KBDocument
from utils import util

logger = logging.getLogger('wmt_llm')
logger.setLevel(logging.DEBUG)


class WalmartLLM(LLM):
    url: str

    @classmethod
    def get_instance(cls):
        url = "https://wmtllmgateway.stage.walmart.com/wmtllmgateway/v1/openai"
        return cls(url=url)

    @property
    def _llm_type(self) -> str:
        return 'WalmartLLM'

    def _call(
            self,
            prompt: str,
            stop: Optional[List[str]] = None,
            run_manager: Optional[CallbackManagerForLLMRun] = None,
            **kwargs: Any,
    ) -> str:

        body = {
            "model": "gpt-4o",
            "model-version": "2024-05-13",
            "api-version": "2024-02-01",
            "task": "chat/completions",
            "model-params": {
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.1
            }
        }
        headers = util.generate_headers("WMTLLMGATEWAY", "stage")
        headers["Content-Type"] = "application/json"
        response = requests.post(self.url, json=body, headers=headers)
        return self._extract_answer(response)

    def _extract_answer(self, response: requests.Response) -> str:
        if not response.ok:
            raise ValueError("Could not generate response: " + response.text)

        try:
            resp_json = response.json()
            if 'choices' in resp_json:
                choice = resp_json['choices'][0]
                if 'message' in choice and 'content' in choice['message']:
                    return choice['message']['content']
        except (KeyError, requests.JSONDecodeError, IndexError) as e:
            raise ValueError("Could not generate response: " + e)

    @staticmethod
    def create_prompt_string(query: str, knowledge_base: List[KBDocument]) -> str:
        prompt = f"""
Act as a Question-and-Answering Assistant. Refer to all the Context-Documents and create a final answer from those documents only.
If you do not know the answer, respond with \"I don't know\". Do not try to make up an answer.
                        
QUESTION: {query}
=========
"""
        ctxt_str = ""
        for idx, doc in enumerate(knowledge_base):
            ctxt_str += f"ContextDocument {idx}: {doc.text}\n\n"

        return prompt + ctxt_str
