import os

# Load configs from any other system that we want to configure.
# For now, there's nothing else
configs_in_wcnp = {}


def _get_config_wcnp(property: str, optional=False, default=None):
    if not optional and property not in configs_in_wcnp:
        if default is None:
            raise Exception(f"Undefined {property}")
    return configs_in_wcnp[property] if property in configs_in_wcnp else default


def _get_config(property: str, optional=False, default=None):
    return os.environ[property] if property in os.environ else _get_config_wcnp(property, optional)


AUTH_TYPE = _get_config('AUTH_TYPE', False)
GATEWAY_ENV = _get_config('GATEWAY_ENV', True, 'stage')
EMBEDDING_MODEL = _get_config('EMBEDDING_MODEL', True, 'text-embedding-ada-002')
EMBEDDING_MODEL_VERSION = _get_config('EMBEDDING_MODEL_VERSION', True, '2')


CONSUMER_ID = _get_config('CONSUMER_ID', True)
CONSUMER_KEY_VERSION = _get_config('CONSUMER_KEY_VERSION', True)


