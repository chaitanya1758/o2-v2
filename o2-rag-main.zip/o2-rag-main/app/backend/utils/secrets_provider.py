import os

# Load secrets from any other system that we want to secreture.
# For now, there's nothing else
secrets_in_wcnp = {}


def _get_secret_wcnp(property: str, optional=False):
    if not optional and property not in secrets_in_wcnp:
        raise Exception(f"Undefined {property}")
    return secrets_in_wcnp[property] if property in secrets_in_wcnp else None


def _get_secret(property: str, optional=False):
    return os.environ[property] if property in os.environ else _get_secret_wcnp(property, optional)


CLIENT_PRIVATE_KEY_BASE64 = _get_secret('CLIENT_PRIVATE_KEY_BASE64', True)
X_API_KEY = _get_secret('X_API_KEY', True)
