import base64
import os
import time

from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5

from utils import config_provider, secrets_provider


def base64_encode_file(input_file: str):
    if not os.path.isfile(input_file):
        raise Exception(f"File {input_file} is not existing")
    content = ""
    with open(input_file, 'r') as f:
        content = f.read()

    return base64.b64encode(content.encode("ascii")).decode("ascii")


def base64_decode(encoded: str):
    return base64.b64decode(encoded.encode("ascii")).decode("ascii")


def get_sr_signature(svc_env: str):
    epoch_time = int(time.time()) * 1000
    data = f"{config_provider.CONSUMER_ID}\n{epoch_time}\n{config_provider.CONSUMER_KEY_VERSION}\n"
    rsakey = RSA.importKey(base64_decode(secrets_provider.CLIENT_PRIVATE_KEY_BASE64))
    signer = PKCS1_v1_5.new(rsakey)
    digest = SHA256.new()
    digest.update(data.encode('utf-8'))
    sign = signer.sign(digest)
    return base64.b64encode(sign).decode("utf-8"), str(epoch_time), config_provider.CONSUMER_ID,\
           svc_env, config_provider.CONSUMER_KEY_VERSION


def generate_sr_headers(svc_name: str, svc_env: str):
    sign, ts, cid, env, ver = get_sr_signature(svc_env)
    # Wrap the values in a dictionary
    return {
        "WM_SEC.AUTH_SIGNATURE": sign,
        "WM_CONSUMER.INTIMESTAMP": ts,
        "WM_CONSUMER.ID": cid,
        "WM_SVC.NAME": svc_name,
        "WM_SVC.ENV": env,
        "WM_SEC.KEY_VERSION": ver
    }


def generate_apikey_headers():
    return {
        "X-Api-Key": secrets_provider.X_API_KEY
    }


def generate_headers(svc_name: str = None, svc_env: str = None):
    if config_provider.AUTH_TYPE == 'SR':
        if svc_name is None or svc_env is None:
            raise ValueError("Service Name and Env missing")
        return generate_sr_headers(svc_name, svc_env)
    else:
        return generate_apikey_headers()
