import logging
import time
from typing import List

import requests
from langchain_core.embeddings import Embeddings
from utils import config_provider

from utils import util

logger = logging.getLogger('wmt_llm')
logger.setLevel(logging.DEBUG)

doc_chunk = 25

class WalmartEmbeddings(Embeddings):

    @classmethod
    def get_instance(cls):
        return cls()

    def embed_query(self, text: str) -> List[float]:
        embeddings = self.embed_documents([text])
        return embeddings[0] if len(embeddings) > 0 else []

    def embed_documents(self, documents: List[str]) -> List[List[float]]:

        resp_vector = []
        counter, total = 0, len(documents)

        for idx in range(0, total, doc_chunk):
            d = documents[idx:idx+doc_chunk]

            url = "https://wmtllmgateway.stage.walmart.com/wmtllmgateway/v1/openai"
            body = {
                "model": config_provider.EMBEDDING_MODEL,
                "model-version": config_provider.EMBEDDING_MODEL_VERSION,
                "api-version": "2024-02-01",
                "task": "embeddings",
                "model-params": {
                    "input": d,
                }
            }
            headers = util.generate_headers("WMTLLMGATEWAY", "stage")
            headers["Content-Type"] = "application/json"
            response = self.get_response_with_retries(url, body, headers)
            counter += 1
            logger.info(f"Generated embeddings for {idx+doc_chunk} documents out of {total} documents")
            vector = self._extract_embeddings_vector(response)
            resp_vector.extend(vector)

        return resp_vector

    def get_response_with_retries(self, url, body, headers, attempt=0):

        if attempt >= 3:
            raise ValueError("Retries exhausted while generating embedding for document")

        response = requests.post(url, json=body, headers=headers)
        if response.ok:
            return response
        elif response.status_code == 429:
            logger.debug("Rate-Limited while generating embedding, retry after 10s")
            logger.debug("Response received: %s" % response.text)
            time.sleep(10)
            return self.get_response_with_retries(url, body, headers, attempt+1)
        else:
            raise ValueError("Could not generate embeddings due to %s" % response.text)

    def _extract_embeddings_vector(self, response: requests.Response) -> List[List[float]]:
        if not response.ok:
            raise ValueError("Could not generate embedding for document due to %s" % response.text)

        try:
            resp_json = response.json()
            resp_data = resp_json['data']
            embeddings = []
            for rd in resp_data:
                embeddings.append(rd['embedding'])
            return embeddings
        except (KeyError, requests.JSONDecodeError) as e:
            return []
