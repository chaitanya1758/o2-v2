import json
from typing import List

from models.document import KBDocument


class RAGResponse:

    def __init__(self, query: str, answer: str, sources: List[KBDocument]):
        self.query = query
        self.answer = answer
        self.sources = sources

    def as_dict(self):
        return {
            "query": self.query,
            "answer": self.answer,
            "sources": {doc.source: doc.text for doc in self.sources}
        }

    def __str__(self) -> str:
        return json.dumps(self.as_dict())