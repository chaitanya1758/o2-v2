class KBDocument:

    def __init__(self, text: str, source: str):
        self.text = text
        self.source = source
