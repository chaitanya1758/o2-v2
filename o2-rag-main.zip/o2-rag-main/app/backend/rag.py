import logging
from typing import List

from embedding import WalmartEmbeddings
from llm import WalmartLLM
from models.document import KBDocument
from models.rag_response import RAGResponse
from vectordb import VectorDB

logger = logging.getLogger('wmt_llm')
logger.setLevel(logging.DEBUG)
class RAG:

    def __init__(self):
        self.embedding = WalmartEmbeddings.get_instance()
        self.vectordb = VectorDB.get_instance(embedding=self.embedding)
        self.llm = WalmartLLM.get_instance()
        logger.info("Application is ready to use now...")

    def retrieve(self, query: str) -> List[KBDocument]:
        return self.vectordb.search(query)

    def generate(self, query: str, knowledge_base: List[KBDocument]) -> RAGResponse:
        prompt = self.llm.create_prompt_string(query, knowledge_base)
        logger.debug("Prompt = %s" % prompt)
        response = self.llm.invoke(prompt)
        logger.debug("HTTP Response from LLM: %s" % response)

        ragResp = RAGResponse(query=query, answer=response, sources=knowledge_base)
        return ragResp

    def retrieve_and_generate(self, query):
        knowledge = self.retrieve(query)
        logger.debug("Knowledge base retrieved: %s" % knowledge)
        response = self.generate(query, knowledge)
        logger.debug("Response generated: %s" % response)
        return response
