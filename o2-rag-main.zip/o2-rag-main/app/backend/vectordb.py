import logging
from typing import List

from langchain_community.document_loaders import DirectoryLoader
from langchain_community.document_loaders import TextLoader
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore
from langchain_milvus import Milvus

from models.document import KBDocument

logger = logging.getLogger('wmt_llm')
logger.setLevel(logging.DEBUG)


class VectorDB:
    embedding: Embeddings
    vectorstore: VectorStore

    @classmethod
    def get_instance(cls, embedding: Embeddings):
        vectorstore = VectorDB.initialize_vectordb(embedding)
        return cls(embedding=embedding, vectorstore=vectorstore)

    def __init__(self, embedding, vectorstore):
        self.embedding = embedding
        self.vectorstore = vectorstore

    @classmethod
    def initialize_vectordb(cls, embedding) -> Milvus:
        loader = DirectoryLoader('app/backend/data', glob="**/*.html", loader_cls=TextLoader)
        html_chunks: List[Document] = loader.load()
        logger.info("Documents read in from data/ folder. Creating embeddings now")

        vectorstore = Milvus.from_documents(
            documents=html_chunks,
            embedding=embedding,
            connection_args={
                "uri": "milvus/milvus.db",
            },
            # Override LangChain default values for Milvus.
            consistency_level="Eventually",
            drop_old=True,
            index_params={
                "metric_type": "COSINE",
                "index_type": "AUTOINDEX",
                "params": {}
            }
        )
        logger.info("VectorDB initialized with documents")
        return vectorstore

    def search(self, query: str) -> List[KBDocument]:
        retriever = self.vectorstore.as_retriever(limit=4)
        docs = self.vectorstore.similarity_search(query, k =4)

        retrieved_docs = []
        for d in docs:
            kb = KBDocument(
                d.page_content,
                d.metadata['source'] if d.metadata and 'source' in d.metadata else '')
            retrieved_docs.append(kb)
        return retrieved_docs
