#!/bin/bash
set -e

WORKDIR="."
LOGDIR="."

if [ ! -d ./milvus ]
then
  mkdir milvus
fi
# Export all the secrets and configs into the environment
# shellcheck disable=SC2046
env_file=llm_consumer.env

while IFS= read -r line; do
    key=$(echo $line | awk -F'=' '{print $1}')
    val=$(echo $line | awk -F'=' '{print $2}')
    export $key="$val"
done <$env_file

export PYTHONPATH=$PYTHONPATH:${WORKDIR}/backend:${WORKDIR}/frontend
# Run the Flask App for Backend
echo "Starting the Backend Flask App..."
python3 ${WORKDIR}/app/backend/app.py 2>&1 | tee ${LOGDIR}/backend.log

