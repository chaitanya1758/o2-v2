#!/bin/bash
set -e

WORKDIR="$PWD/app"

# Export all the secrets and configs into the environment
# shellcheck disable=SC2046
env_file=${PWD}/llm_consumer.env


while IFS= read -r line; do
    key=$(echo $line | awk -F'=' '{print $1}')
    val=$(echo $line | awk -F'=' '{print $2}')
    export $key="$val"
done <$env_file

export PYTHONPATH=$PYTHONPATH:${WORKDIR}/backend:${WORKDIR}/frontend
# Run the Streamlit App for Frontend
echo "Starting the Frontend..."
python3 -m streamlit run ${WORKDIR}/frontend/chat_app.py --server.headless true
