#!/bin/bash
set -e

WORKDIR="."
LOGDIR="."


# Export all the secrets and configs into the environment
# shellcheck disable=SC2046
env_file=llm_consumer.env

while IFS= read -r line; do
    key=$(echo $line | awk -F'=' '{print $1}')
    val=$(echo $line | awk -F'=' '{print $2}')
    export $key="$val"
done <$env_file

export PYTHONPATH=$PYTHONPATH:${WORKDIR}/backend:${WORKDIR}/frontend
# Run the Flask App for Backend
echo "Starting the Backend Flask App..."
python3 ${WORKDIR}/app/backend/app.py 1>${LOGDIR}/backend.log 2>&1 &
echo $! >${WORKDIR}/backend.pid

# Run the Streamlit App for Frontend
echo "Starting the Frontend..."
python3 -m streamlit run ${WORKDIR}/app/frontend/chat_app.py --server.headless true 2>&1 | tee ${LOGDIR}/frontend.log &
echo $! >${WORKDIR}/frontend.pid

tail -F ${LOGDIR}/backend.log
