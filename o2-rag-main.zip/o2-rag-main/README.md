o2-rag
# Element Generative AI Starter Kit for Experimentation
Q&A starter kit for providing an interface for querying LLM with context retrieved from Milvus Lite Vector DB

Provides functionalities for citations (with viewable documents), thought process (if using agents), and viewing 
retrieved documents.

## Starter Kit Preparation
This starter kit is pre-baked with benefits related information and is able to deploy locally as a streamlit UI with a Flask based micro-service.

### Provide configurations
Update llm_consumer.env file and provide API key you have received for LLM Gateway Sandbox or non-prod environment.

`llm_consumer.env` file:
```
X_API_KEY=<API key received for GenAI LLM Gateway Sandbox / non-prod>
```

### Steps to bring up the starter kit application components in your laptop
1. Make sure you have conda installed in your laptop. You can get miniconda downloaded from here: https://www.anaconda.com/docs/getting-started/miniconda/install
2. Execute the following command to create a conda environment with python 3.10, providing a meaningful conda-env-name.
```
	conda create -n o2-rag-env python=3.10
```
3. Activate the newly created environemtn
```
	conda activate o2-rag-env
```
4. Install the required python library dependencies
```
	pip install -r requirements.txt
```
5. Start backend service
```
	./run_backend_service.sh
```
   This should start the backend service and should output messages as below:
<pre>
   * Running on all addresses (0.0.0.0)
   * Running on http://127.0.0.1:8080
   * Running on http://your-laptop-ip-address:8080
  Press CTRL+C to quit
</pre>
6. In a different terminal window, activate the same conda environment and start the frontend streamlit service
```
	conda activate o2-rag-env
        ./run_frontend_service.sh
```
   This should start the frontend application and should output messages as below:
<pre>
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://your-laptop-ip-address:8501
</pre>
7. Now, you can open http://localhost:8501 in your browser
