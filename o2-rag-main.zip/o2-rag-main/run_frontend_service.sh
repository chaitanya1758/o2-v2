#!/bin/bash
set -e

WORKDIR="."
LOGDIR="."


# Export all the secrets and configs into the environment
# shellcheck disable=SC2046
env_file=llm_consumer.env

while IFS= read -r line; do
    key=$(echo $line | awk -F'=' '{print $1}')
    val=$(echo $line | awk -F'=' '{print $2}')
    export $key="$val"
done <$env_file

export PYTHONPATH=$PYTHONPATH:${WORKDIR}/backend:${WORKDIR}/frontend

# Run the Streamlit App for Frontend
echo "Starting the Frontend..."
python3 -m streamlit run ${WORKDIR}/app/frontend/chat_app.py --server.headless true 2>&1 | tee ${LOGDIR}/frontend.log
