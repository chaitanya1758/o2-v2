from langchain_openai.chat_models import AzureChatOpenAI

import os
import ssl
import httpx
from utils.config import get_headers


WMT_CA_PATH = os.getenv('REQUESTS_CA_BUNDLE', \
                        os.getenv('SSL_CERT_FILE', '/etc/ssl/certs/ca-bundle.crt'))


def create_openai_chat_client(model, model_version=None, api_version='2024-10-21', **kwargs):
    headers = get_headers()

    # Build a custom client with Walmart CAs and Headers built into it
    context = ssl.create_default_context()
    context.load_verify_locations(WMT_CA_PATH)
    client = httpx.Client(verify=context, headers=headers)
    async_client = httpx.AsyncClient(verify=context, headers=headers)

    llm_chat = AzureChatOpenAI(openai_api_key="<ignored>",
                               model=model if model_version is None else f"{model}@{model_version}",
                               api_version=api_version,
                               azure_endpoint='https://wmtllmgateway.stage.walmart.com/wmtllmgateway',
                               http_client=client,
                               http_async_client=async_client,
                               **kwargs)
    return llm_chat