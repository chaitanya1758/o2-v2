try:
    from agent.mcp_agent import weather_forecast
except ImportError:
    import sys
    sys.path.append("app_server")
    
from fastapi import FastAPI, Body
from fastapi.responses import StreamingResponse
from agent.mcp_agent import weather_forecast
import logging
import sys
import json
import os

os.environ['SSL_CERT_FILE'] = './ca-bundle.crt'
logging.basicConfig(level=logging.INFO, stream=sys.stderr)

app = FastAPI()

@app.get("/ask_weather")
async def ask_question(city: str):
    """ Given a city name, return the weather in that city """
    logging.info(f"Received request for weather in {city}")
    llm_resp = await weather_forecast(f"What's the weather in {city}")
    logging.info(f"LLM response: {llm_resp}")
    if llm_resp.get('messages') is not None:
        return llm_resp['messages'][-1].content
    else:
        return llm_resp

@app.post("/ask_echo")
async def echo(body: dict = Body(...)):
    """ Given the body, return it again """
    logging.info(f"Received request for echo {body}")
    return body

@app.get("/health")
def health_check():
    """ Health check endpoint """
    return {"status": "ok"}