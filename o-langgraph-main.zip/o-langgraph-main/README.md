# Element AI Agent with LangGraph

## Overview

This project provides a framework for building and deploying AI agents using Element GenAI, LangGraph and MCP. It includes a FastAPI server that exposes the agent's capabilities through REST endpoints. This can be deployed on WCNP using KITT and is authenticated via Service Registry.

### Key Components

- **LangGraph**: Framework for building stateful agents with chains and tools
- **Model Context Protocol (MCP)**: Protocol for connecting to different tool services
- **FastAPI**: Web server for exposing REST endpoints
- **OpenAI Client**: Integration with Azure OpenAI models through Element GenAI Gateway

### Agent Architecture

The agent is built using LangGraph's ReAct framework, which follows a reasoning and action approach:

1. The agent processes user queries through an LLM
2. The LLM decides which tools to call based on the query
3. Tools are accessed via MCP services (external or internal)
4. Results are processed and returned to the user

The current implementation connects to:

- Element GenAI LLM Gateway to access OpenAI's GPT-4o-Mini model
- A Sample MCP server hosted by Element Team

## Environment Setup and Local Testing

### Installing Dependencies

Before you start, make sure you have the following prerequisites:

1. **Python installed** (version 3.10 or higher recommended).  
   You can check your Python version with:
   ```bash
   python3 --version
   ```
2. **Familiarity with Python virtual environments** (using `venv`, `conda`, or `uv`).  
   You can use any virtual environment tool you prefer.
3. **An IDE (Optional)** You can use PyCharm, VSCode, Neovim or any other IDE of your choice.

Below are steps to set up a new virtual environment using Python’s built-in `venv` module and install dependencies:

```bash
# Create a new virtual environment named 'venv'
python3 -m venv venv

# Activate the virtual environment
source venv/bin/activate

# Install dependencies from requirements.txt
pip install -r requirements.txt
```

If you use `conda` or `uv`, feel free to set up your environment using those tools instead.


### Run application locally

> [!NOTE]
> If you have to run the server locally, then you will need to ensure the Akeyless Secrets are pulled into your local system and made available in /etc/secrets/. 

> Alternatively, you can edit the `utils/config.py` file and read the secrets from a different folder.

To start the agent server, execute the following from the root directory:

```bash
export SSL_CERT_FILE=/path/to/ca-certificates.crt
export PYTHONPATH=$PWD/app_server:$PYTHONPATH

python -m fastapi run --host 0.0.0.0 --port 8080 app_server/app.py
```

This should bring up the server at `http://localhost:8080`

### Testing the Agent

In Local Deployment - there is no authentication enabled. So you can directly call the API without any auth headers:

```bash
curl http://localhost:8080/ask_weather?city=LA
```

### Extending the Agent

To extend the agent with additional tools:

1. Add a new MCP service connection in `app_server/agent/mcp_agent.py`:

    ```python
    client = MultiServerMCPClient(
        {
            "weather": {
                "transport": "streamable_http",
                "url": get_config_value("weather_mcp_url")
            },
            "new_tool": {
                "transport": "streamable_http",
                "url": get_config_value("new_tool_mcp_url")
            }
        }
    )
    ```

2. Create a new endpoint in `app_server/app.py` to utilize your tool:

    ```python
    @app.get("/use_new_tool")
    async def use_new_tool(param: str):
        """ Use the new tool with the provided parameter """
        logging.info(f"Received request for new tool with param {param}")
        llm_resp = your_agent_function(f"Use the new tool with {param}")
        logging.info(f"LLM response: {llm_resp}")
        return llm_resp
    ```

3. Implement a corresponding agent function in the appropriate module

## Deploying and Testing the Application

### Setting up the secrets

In order to connect with LLM Gateway, the API Key needs to be securely stored in Akeyless.

1. Login to [Akeyless](https://akeyless.gw.prod.glb.us.walmart.net:18888) 
2. Go to the path /Prod/WCNP/homeoffice/txn-tools
3. Create a secret called `dev/llmgateway-api-key` and save the LLM Gateway API Key in that.

Alternatively, if you are using Service Registry to connect to LLM Gateway, you will need to store the SR Private Key in Akeyless. After that, you will have to modify both the kitt.yml and the corresponding code for generating the request headers in `llm/openai_client.py`

### Deploying

To deploy your agent, simply commit your changes to the `main` branch of your repository. This will automatically trigger a WCNP deployment using KITT. You can monitor the deployment progress and receive updates in the Slack channel you provided during the setup process.

No manual deployment steps are needed—just push to `main` and let the automation handle the rest!

### Testing the Deployment

Once the application has been deployed in WCNP, you can test out the API using curl and authenticating via Service Registry.

1. Add a consumer to your sr.yaml. A dummy entry has been provided by default
2. Generate the headers for your consumer using [SR Tools](https://reg.soa.walmart.com/tools)
3. Use the following curl call to validate that the agent is working:
   ```
   curl -L -X GET 'https://o-langgraph.dev.walmart-web.walmart.com/ask_weather?city=CA' \
    -H 'WM_CONSUMER.ID: <your-consumer-id>' \
    -H 'WM_SVC.NAME: O-LANGGRAPH' \
    -H 'WM_SVC.ENV: dev' \
    -H 'WM_SEC.KEY_VERSION: 1' \
    -H 'WM_SEC.AUTH_SIGNATURE: <auth-signature>' \
    -H 'WM_CONSUMER.INTIMESTAMP: <timestamp>'
   ```

### Observability

The deployed application has the following Observability tools built into it:

1. Metrics Dashboard in MMS:
    https://grafana.mms.walmart.net/d/7Wushy_mk/apps?orgId=1&var-datasource=non-production&var-namespace=cxo&var-cluster_id=All&var-app=o-langgraph&var-interval=$__auto_interval_interval&var-long_interval=$__auto_interval_long_interval

2. Trace Store Dashboard (Wolly):
   https://wolly.non-prod.walmart.com/?from=now-1h&to=now&var-datasource=main-prom-uid&var-service=O-LANGGRAPH&var-traceids=$__all

3. WCNP Portal:
   https://dx.walmart.com/wcnp/workloads/namespace/cxo/dev/app/o-langgraph?active_tab=details